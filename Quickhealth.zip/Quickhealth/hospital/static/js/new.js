$('#doctor-form' ).on( "submit", function(e) {
    document.getElementById('load1').style.display='flex'
    document.getElementById('link').value=window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
    var dataString = $(this).serialize();
    $.ajax({
      type: "POST",
      url: "/addDoctor/",
      data: dataString,
      success: function (msg) {
        if (msg == 'exists'){
            toastr.error('Account already exists');
            document.getElementById('load1').style.display='none';
            // document.getElementById('doctor-form').reset();
            document.getElementById('result').innerHTML='sucessful error';
          }
        else{
             toastr.success('Created Successfully, Login details are sent on mail');
            document.getElementById('load1').style.display='none';
            document.getElementById('add_slot').textContent = '';
            document.getElementById('result').innerHTML='sucessful';
        }
      },
      error: function() {
        toastr.error('Something went wrong');
          document.getElementById('load1').style.display='none'
          document.getElementById('result').innerHTML='error';
      }
    });
   
    e.preventDefault();
   });